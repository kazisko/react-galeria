
const Kot=({wys=100 ,szer=100})=>{
    return(
        <>
        zdjecie kota<br></br>
            <img src={"cat.jpg"} style={{height:wys, width:szer}}/>
        </>
    )
}
export default Kot;