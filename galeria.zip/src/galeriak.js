import Kot from './kot';
function Gk() {
    return (
      <div className="App">
        <Kot wys={500} szer={200}/>
      </div>
    );
  }
  
  export default Gk;