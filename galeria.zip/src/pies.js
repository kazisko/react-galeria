
const Pies=({wys=100 ,szer=100})=>{
    return(
        <>
            <img src={"dog.jpg"} style={{height:wys, width:szer}}/>
        </>
    )
}
export default Pies;