import Pies from "./pies";

function Gp() {
    return (
      <div className="App">
        zdjecie psa <br></br>
        <Pies wys={500} szer={1000}/>
      </div>
    );
  }
  
  export default Gp;